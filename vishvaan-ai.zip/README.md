# Vishvaan — Philosophical AI Mentor

A reflective, internet-connected Python AI assistant that learns simple intents and answers questions with both reasoning and web knowledge.

## Features
- Philosophical personality
- Trains a small NumPy classifier on startup
- Uses DuckDuckGo for live info (no API key)
- Supports `calc:` for arithmetic

## Usage
```bash
pip install -r requirements.txt
python vishvaan.py
```

Type `quit` to exit.
