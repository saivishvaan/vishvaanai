#!/usr/bin/env python3
"""Vishvaan — a philosophical AI mentor with web-connected knowledge."""
import requests, random, numpy as np, math

AI_NAME = "Vishvaan"

def tokenize(s): return s.lower().replace("?", " ?").replace("!", " !").split()

intents = [
    {"tag": "greeting", "patterns": ["hi", "hello", "hey"], "responses": [
        "Greetings, traveler. I am Vishvaan.",
        "Hello. May your curiosity bring insight."
    ]},
    {"tag": "goodbye", "patterns": ["bye", "goodbye"], "responses": [
        "Until our paths cross again.",
        "Farewell. Reflect upon what you learn."
    ]},
    {"tag": "thanks", "patterns": ["thanks", "thank you"], "responses": [
        "You are welcome.", "It was my pleasure."
    ]},
    {"tag": "name", "patterns": ["what is your name", "who are you"], "responses": [
        "I am Vishvaan, a humble digital thinker."
    ]},
]

vocab = sorted({w for intent in intents for p in intent["patterns"] for w in tokenize(p)})
tags = [i["tag"] for i in intents]

def bag_of_words(tokens): return np.array([1.0 if w in tokens else 0 for w in vocab], dtype=float)
X, y = [], []
for i, intent in enumerate(intents):
    for p in intent["patterns"]:
        X.append(bag_of_words(tokenize(p))); y.append(i)
X, y = np.array(X), np.array(y)

input_size, hidden_size, output_size = X.shape[1], 8, len(tags)
W1, b1 = np.random.randn(input_size, hidden_size), np.zeros(hidden_size)
W2, b2 = np.random.randn(hidden_size, output_size), np.zeros(output_size)

def softmax(z): e = np.exp(z - np.max(z)); return e / e.sum()
def predict(sentence):
    x = bag_of_words(tokenize(sentence))
    a1 = np.tanh(x @ W1 + b1)
    probs = softmax(a1 @ W2 + b2)
    idx = np.argmax(probs)
    return tags[idx] if probs[idx] > 0.3 else None

def duckduckgo_search(q):
    try:
        r = requests.get("https://api.duckduckgo.com/", params={"q": q, "format": "json"}, timeout=5)
        j = r.json(); return j.get("AbstractText") or "No summary found."
    except Exception as e:
        return f"Web search failed: {e}"

def vishvaan_chat():
    print(f"{AI_NAME}: Greetings, I am {AI_NAME}. Type 'quit' to exit.")
    while True:
        msg = input("You: ").strip()
        if msg.lower() in ["quit", "exit"]: break
        if msg.startswith("calc:"):
            try:
                expr = msg.split(":",1)[1]; print(f"{AI_NAME}: {eval(expr, {'__builtins__':None}, {'math':math})}")
            except: print(f"{AI_NAME}: Invalid expression.")
            continue
        tag = predict(msg)
        if tag:
            res = random.choice(next(i["responses"] for i in intents if i["tag"]==tag))
            print(f"{AI_NAME}: {res}")
        else:
            print(f"{AI_NAME}: Hmm... let me see what the world knows.")
            print(f"{AI_NAME}: {duckduckgo_search(msg)}")

if __name__ == "__main__":
    vishvaan_chat()
